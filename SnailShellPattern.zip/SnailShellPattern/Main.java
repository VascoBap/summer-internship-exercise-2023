public class Main {
    public static void main(String[] args) {
    	int[][] snail = {{1, 2, 3,10}, {4, 5, 6,11}, {7, 8, 9,12}, {13,14,15,16}};
        System.out.println(SnailShellPattern.getSnailShell(snail));
    }
}