import java.util.Arrays;

public class SnailShellPattern {
	public static int[] getSnailShell(int[][] snail) {
		int row = 0;
		int col = 0;
		int l = snail.length;
		int ini = 0;
		int pointer = 0;
		int[] result = new int [snail.length*snail.length];
		boolean reverse = false;
		if(!verify(snail)) //verifica os par�metros da matriz
			return null;
		
		while(true) {
			
			if(col < l-1 && !reverse) { // dire��o da esquerda para a direita
				
				result[pointer]=snail[row][col];
				pointer++;
				col++;
				
			}else if(col == l-1 && !reverse) { // dire��o a descer
				
				result[pointer]=snail[row][col];
				pointer++;
				row++;
				
			}else if(row == l-1 && col > ini &&  reverse) { //dire��o da direita para a esquerda
				
				result[pointer]=snail[row][col];
				pointer++;
				col--;
			}else if(col == ini &&  reverse) { //dire��o a subir
				
				result[pointer]=snail[row][col];
				pointer++;
				row--;
				
			} 
			
			if(col == l-1 && row == l-1) { // reverse serve para distinguir as dire��es horizontais e as verticais
				reverse = true;
			}
			
			
			if(col == ini && row == ini+1 && reverse) { //reduzir o tamanho da matriz para interar sobre as matrizes interiores
				ini++;
				reverse=false;
				l--;
			}
			
			
			if(result[snail.length*snail.length-1]!= 0) { //Se j� tiver iterado pela matriz inteira sa� do loop
				break;
			}
		}
		
		return result;
	}
	
	public static Boolean verify(int[][]snail) {
		int[][] i = {{}};
		if(snail == null) { 
			System.out.println("The matrix is null");
			return false;
		}
		if(snail == i) { 
			System.out.println("The matrix is empty");
			return false;
		}
		if(snail.length != snail[0].length) {
			System.out.println("The matrix's height and width are different");
			return false;
			}
		for (int j = 1; j < snail.length; j++) {
	        if (snail[j].length != snail[j-1].length) {
	        	System.out.println("The matrix's width has to be always the same length!");
	            return false;
	        }
	    }
		
		
		return true;
	}
}
